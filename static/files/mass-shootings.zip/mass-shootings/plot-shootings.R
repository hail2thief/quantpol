# We're going to look at data on mass-shootings in the US going back to the 1980s.
# Consists of all mass shootings in the US
# Data collected by MotherJones here (https://www.motherjones.com/politics/2012/12/mass-shootings-mother-jones-full-data/)

# load the tidyverse
library(tidyverse)

# loads data from the data/ folder
mass_shootings = read_csv('data/mass-shootings.csv')

# look at data
mass_shootings

# LINEGRAPH: plot fatalities over date
## TRY: add points so we can see the individual shootings
## TRY: adjusting size = NUMBER in geom_line(), what looks best?
## TRY: adjusting color = "color" in geom_line(), what looks best?


## plot age of shooter over date


# SCATTERPLOT: plot injured over date
## TRY: add labels so we can see what that huge outlier is
## TRY: adjusting color = "color" in geom_point(), what looks best?


# remove the outlier
shootings_no_outlier = 
  mass_shootings %>% 
  filter(date != "") # "!=" means "not equal to"


# SCATTERPLOT: plot again


# SCATTERPLOT: plot fatalities against injured


# BOXPLOT: plot distribution of fatalities across states
# TRY: adding points, what do you learn about Nevada?


# HISTOGRAMS: plot distribution of injuries
## TRY: change number of bins
## TRY: change fill = "color" in geom_histogram()


## plot distribution of age of shooter
## TRY: change number of bins
## TRY: change fill = "color" in geom_histogram()


# BARPLOTS: plot mass shootings by state
## TRY: change fill = "color" in geom_histogram()
shootings_by_state = 
  mass_shootings %>% 
  count(state)


# BARPLOTS: plot average mass shooting fatalities by month
avg_fatality_day =
  mass_shootings %>% 
  group_by(day) %>% 
  summarise(avg_fatality = mean(fatalities))

